import{_ as n,c as e,o}from"./B2cWwQEc.js";const t={};function c(_,r){return o(),e("div",null," Component: testcomponent ")}const a=n(t,[["render",c]]);export{a as _};
